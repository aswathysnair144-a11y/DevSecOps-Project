<?php
include 'db.php';
?>
<!DOCTYPE html>
<html>
<head><title>Search Users</title></head>
<body>
<h2>Search Users</h2>
<form method="GET">
    Username: <input type="text" name="user" value="<?php echo $_GET['user'] ?? ''; // VULNERABILITY: XSS - reflected input ?>">
    <!-- Try: <script>alert('XSS')</script> in the search box -->
    <button type="submit">Search</button>
</form>

<?php
if (isset($_GET['user'])) {
    $user = $_GET['user']; // VULNERABILITY #1: No input sanitization

    // VULNERABILITY #2: SQL Injection via GET parameter
    // Try: ' UNION SELECT 1,username,password FROM users --
    $query = "SELECT * FROM users WHERE username='$user'";
    $result = mysqli_query($conn, $query);

    echo "<h3>Results:</h3>";
    if ($result && mysqli_num_rows($result) > 0) {
        echo "<table border='1'><tr><th>ID</th><th>Username</th><th>Password</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            // VULNERABILITY #3: Displaying raw passwords
            // VULNERABILITY #4: XSS via unsanitized database output
            echo "<tr><td>{$row['id']}</td><td>{$row['username']}</td><td>{$row['password']}</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No users found for: $user</p>"; // VULNERABILITY #5: Reflected XSS
    }
}
?>
</body>
</html>
