<!DOCTYPE html>
<html>
<head>
    <title>VulnApp - Login</title>
    <style>
        body { font-family: Arial; background: #f0f0f0; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 300px; }
        h2 { text-align: center; color: #d9534f; }
        input { width: 100%; padding: 10px; margin: 8px 0; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #d9534f; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .warn { background: #fff3cd; border: 1px solid #ffc107; padding: 10px; border-radius: 4px; font-size: 12px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="box">
        <h2>⚠️ VulnApp</h2>
        <div class="warn">This is a <strong>deliberately vulnerable</strong> application for security training only.</div>
        <!-- VULNERABILITY: No CSRF token, plain text password field, no rate limiting -->
        <form action="login.php" method="POST">
            Username: <input type="text" name="username" placeholder="Try: admin' --">
            Password: <input type="password" name="password" placeholder="password">
            <button type="submit">Login</button>
        </form>
        <p style="text-align:center; margin-top:15px;"><a href="search.php">Search Users</a> | <a href="comment.php">Comments</a></p>
    </div>
</body>
</html>
