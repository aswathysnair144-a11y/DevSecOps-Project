-- ============================================
-- VulnApp Database Setup
-- SSDLC Lab - Vulnerable PHP Application
-- ============================================

CREATE DATABASE IF NOT EXISTS vulnapp;
USE vulnapp;

DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL  -- VULNERABILITY: Plaintext passwords, should use bcrypt
);

-- VULNERABILITY: Weak/default credentials stored in plaintext
INSERT INTO users VALUES (1, 'admin', 'admin123');
INSERT INTO users VALUES (2, 'john', 'password');
INSERT INTO users VALUES (3, 'alice', '123456');
INSERT INTO users VALUES (4, 'bob', 'qwerty');

-- ============================================
-- SECURE VERSION (for comparison)
-- ============================================
-- CREATE TABLE users_secure (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     username VARCHAR(50) NOT NULL UNIQUE,
--     password_hash VARCHAR(255) NOT NULL,  -- Use bcrypt/argon2
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     last_login TIMESTAMP NULL,
--     login_attempts INT DEFAULT 0
-- );
