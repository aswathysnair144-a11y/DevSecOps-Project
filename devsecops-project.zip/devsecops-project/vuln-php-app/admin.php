<?php
// VULNERABILITY #1: Hardcoded secret key (security through obscurity)
// Try: http://localhost/admin.php?key=secret123
$key = $_GET['key'] ?? '';

if ($key == "secret123") { // VULNERABILITY #2: Weak/hardcoded auth key, no timing-safe compare
    // VULNERABILITY #3: No proper session-based authentication
    echo "<h1>Admin Panel</h1>";
    echo "<p>Welcome, Admin!</p>";

    // VULNERABILITY #4: Displaying all users with plaintext passwords
    include 'db.php';
    $result = mysqli_query($conn, "SELECT * FROM users");
    echo "<h3>All Users:</h3><table border='1'><tr><th>ID</th><th>Username</th><th>Password (PLAINTEXT!)</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td>{$row['id']}</td><td>{$row['username']}</td><td>{$row['password']}</td></tr>";
    }
    echo "</table>";

    // VULNERABILITY #5: Command injection via GET parameter
    if (isset($_GET['cmd'])) {
        // Try: ?key=secret123&cmd=ls+-la
        echo "<pre>" . shell_exec($_GET['cmd']) . "</pre>"; // Remote Code Execution!
    }
    echo "<form><input name='cmd' placeholder='Run system command'><button>Run</button></form>";
} else {
    echo "<h2>Access Denied</h2><p>Invalid key.</p>";
    echo "<a href='index.php'>Back to Login</a>";
}
?>
