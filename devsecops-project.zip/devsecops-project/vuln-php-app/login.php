<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ===== VULNERABILITY #1: SQL INJECTION =====
    // User input directly concatenated into SQL query - NO sanitization
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Try: username = admin' -- (bypasses password check)
    // Try: username = ' OR '1'='1 (dumps all users)
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";

    // VULNERABILITY #2: Exposing SQL query in output (information disclosure)
    echo "<!-- DEBUG: Query = $query -->"; // Never do this in production!

    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        // VULNERABILITY #3: No session management, no HTTPS enforcement
        $user = mysqli_fetch_assoc($result);

        // VULNERABILITY #4: Storing sensitive data in cookie without httponly/secure flags
        setcookie("user", $user['username'], time() + 3600); // No HttpOnly, No Secure flag

        echo "<h2 style='color:green;'>Welcome, " . $user['username'] . "!</h2>"; // VULNERABILITY #5: XSS - no output encoding
        echo "<p>Login successful. <a href='admin.php?key=secret123'>Go to Admin</a></p>";
    } else {
        echo "<h2 style='color:red;'>Login Failed!</h2>";
        echo "<p>Invalid username or password.</p>";
        echo "<a href='index.php'>Try Again</a>";
    }
}
?>
