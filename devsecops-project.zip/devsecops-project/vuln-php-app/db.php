<?php
// DATABASE CONNECTION - VULNERABLE (No prepared statements, root user, no error handling)
$conn = mysqli_connect("localhost", "root", "", "vulnapp");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
