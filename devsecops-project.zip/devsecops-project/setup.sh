#!/bin/bash
# ============================================================
# DevSecOps Lab - Complete Setup Script
# Run on: Kali Linux / Ubuntu 22.04+
# Usage: sudo bash setup.sh
# ============================================================

set -e  # Exit on error

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

log_info()    { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error()   { echo -e "${RED}[ERROR]${NC} $1"; }
log_section() { echo -e "\n${BLUE}============================================================${NC}"; echo -e "${BLUE} $1${NC}"; echo -e "${BLUE}============================================================${NC}"; }

# ─── Check root ────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run as root (sudo bash setup.sh)"
    exit 1
fi

log_section "DevSecOps Lab Setup Starting..."

# ─── 1. System Update ──────────────────────────────────────
log_section "Step 1: System Update"
apt update && apt upgrade -y
apt install -y curl wget git apt-transport-https gnupg lsb-release software-properties-common
log_info "System updated."

# ─── 2. Install Docker ─────────────────────────────────────
log_section "Step 2: Installing Docker"
if ! command -v docker &> /dev/null; then
    apt install -y docker.io
    systemctl start docker
    systemctl enable docker
    usermod -aG docker $SUDO_USER 2>/dev/null || true
    log_info "Docker installed: $(docker --version)"
else
    log_warn "Docker already installed: $(docker --version)"
fi

# ─── 3. Install Git ────────────────────────────────────────
log_section "Step 3: Installing Git"
apt install -y git
log_info "Git: $(git --version)"

# ─── 4. Install Java + Jenkins ─────────────────────────────
log_section "Step 4: Installing Java + Jenkins"
if ! command -v jenkins &> /dev/null; then
    apt install -y openjdk-17-jdk
    log_info "Java: $(java -version 2>&1 | head -1)"

    curl -fsSL https://pkg.jenkins.io/debian-stable/jenkins.io-2023.key | tee /usr/share/keyrings/jenkins-keyring.asc > /dev/null
    echo "deb [signed-by=/usr/share/keyrings/jenkins-keyring.asc] https://pkg.jenkins.io/debian-stable binary/" | tee /etc/apt/sources.list.d/jenkins.list > /dev/null
    apt update
    apt install -y jenkins
    systemctl start jenkins
    systemctl enable jenkins
    log_info "Jenkins installed and running on http://localhost:8080"
    log_info "Initial Admin Password:"
    cat /var/lib/jenkins/secrets/initialAdminPassword 2>/dev/null || log_warn "Password file not ready yet. Check: sudo cat /var/lib/jenkins/secrets/initialAdminPassword"
else
    log_warn "Jenkins already installed."
fi

# ─── 5. Install SonarQube via Docker ───────────────────────
log_section "Step 5: Deploying SonarQube"
if ! docker ps -a | grep -q sonarqube; then
    docker pull sonarqube:lts-community
    docker run -d \
        --name sonarqube \
        -p 9000:9000 \
        --restart unless-stopped \
        sonarqube:lts-community
    log_info "SonarQube starting on http://localhost:9000 (may take 2-3 minutes)"
    log_info "Default credentials: admin / admin"
else
    log_warn "SonarQube container already exists. Starting it..."
    docker start sonarqube 2>/dev/null || true
fi

# ─── 6. Install Trivy ──────────────────────────────────────
log_section "Step 6: Installing Trivy"
if ! command -v trivy &> /dev/null; then
    wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | apt-key add - 2>/dev/null
    echo "deb https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main" | tee -a /etc/apt/sources.list.d/trivy.list
    apt update
    apt install -y trivy
    log_info "Trivy: $(trivy --version | head -1)"
else
    log_warn "Trivy already installed: $(trivy --version | head -1)"
fi

# ─── 7. Install OWASP ZAP ──────────────────────────────────
log_section "Step 7: Installing OWASP ZAP"
if ! command -v zaproxy &> /dev/null; then
    apt install -y zaproxy 2>/dev/null || {
        log_warn "zaproxy not in apt. Installing via snap..."
        snap install zaproxy --classic 2>/dev/null || log_warn "Snap install failed. Download from https://www.zaproxy.org/download/"
    }
else
    log_warn "OWASP ZAP already installed."
fi

# ─── 8. Deploy DVWA ────────────────────────────────────────
log_section "Step 8: Deploying DVWA"
if ! docker ps | grep -q dvwa; then
    docker pull vulnerables/web-dvwa
    docker run -d \
        --name dvwa \
        -p 8081:80 \
        --restart unless-stopped \
        vulnerables/web-dvwa
    log_info "DVWA deployed at http://localhost:8081"
    log_info "Credentials: admin / password"
else
    log_warn "DVWA already running."
fi

# ─── 9. Install PHP + MySQL for local PHP lab ──────────────
log_section "Step 9: Setting up PHP/MySQL for SSDLC Lab"
apt install -y php php-mysqli mysql-server 2>/dev/null || log_warn "PHP/MySQL install failed. Run manually."

# ─── Summary ───────────────────────────────────────────────
log_section "Setup Complete! Service URLs:"
echo ""
echo -e "  ${GREEN}Jenkins:${NC}   http://localhost:8080"
echo -e "  ${GREEN}SonarQube:${NC} http://localhost:9000  (admin/admin)"
echo -e "  ${GREEN}DVWA:${NC}      http://localhost:8081  (admin/password)"
echo -e "  ${GREEN}App:${NC}       http://localhost:8082  (after pipeline runs)"
echo ""
echo -e "${YELLOW}NOTE: Log out and back in for Docker group changes to take effect.${NC}"
echo -e "${YELLOW}Jenkins initial password: sudo cat /var/lib/jenkins/secrets/initialAdminPassword${NC}"
