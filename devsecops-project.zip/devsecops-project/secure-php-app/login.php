<?php
session_start();

// SECURE: Regenerate session ID on each login attempt to prevent session fixation
session_regenerate_id(true);

include 'db.php';

// SECURE: CSRF Token generation and validation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // SECURE: Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die("CSRF token mismatch - request blocked.");
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // SECURE: Input length validation
    if (strlen($username) > 50 || empty($username) || empty($password)) {
        $error = "Invalid input.";
    } else {
        // SECURE: Prepared statement - prevents SQL injection
        $stmt = $conn->prepare("SELECT id, username, password_hash FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // SECURE: Password verification using bcrypt hash
            if (password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['username'] = $user['username'];

                // SECURE: Redirect after login (PRG pattern)
                header("Location: dashboard.php");
                exit();
            }
        }

        // SECURE: Same error for wrong user/pass (no enumeration)
        $error = "Invalid username or password.";
        // SECURE: Add rate limiting / account lockout here in production
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SecureApp - Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- SECURE: Content Security Policy header (set server-side too) -->
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'none';">
    <style>
        body { font-family: Arial; background: #f0f0f0; display:flex; justify-content:center; align-items:center; height:100vh; margin:0; }
        .box { background:white; padding:40px; border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,.1); width:300px; }
        h2 { text-align:center; color:#2c7a3f; }
        input { width:100%; padding:10px; margin:8px 0; box-sizing:border-box; border:1px solid #ccc; border-radius:4px; }
        button { width:100%; padding:10px; background:#2c7a3f; color:white; border:none; border-radius:4px; cursor:pointer; font-size:16px; }
        .error { color:red; font-size:14px; }
    </style>
</head>
<body>
<div class="box">
    <h2>✅ SecureApp</h2>
    <?php if ($error): ?>
        <p class="error"><?php echo htmlspecialchars($error); // SECURE: Output encoding ?></p>
    <?php endif; ?>
    <form action="login.php" method="POST">
        <!-- SECURE: CSRF token as hidden field -->
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
        Username: <input type="text" name="username" autocomplete="username" required maxlength="50">
        Password: <input type="password" name="password" autocomplete="current-password" required>
        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>
