<?php
session_start();
if (empty($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

// SECURE: CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$comments = [];

// SECURE: Store comments in DB, not flat file
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die("CSRF token mismatch.");
    }

    $comment = trim($_POST['comment'] ?? '');

    // SECURE: Length and content validation
    if (empty($comment) || strlen($comment) > 500) {
        $message = "Comment must be between 1 and 500 characters.";
    } else {
        // SECURE: Store raw text in DB (sanitize on OUTPUT, not input)
        $stmt = $conn->prepare("INSERT INTO comments (user_id, content, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $_SESSION['user_id'], $comment);
        $stmt->execute();
        $stmt->close();
        $message = "Comment posted successfully.";
    }
}

// Fetch comments
$result = $conn->query("SELECT c.content, u.username, c.created_at FROM comments c JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC LIMIT 50");
while ($row = $result->fetch_assoc()) {
    $comments[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Comments</title>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'none';">
</head>
<body>
<h2>Comments</h2>
<?php if ($message): ?>
    <p style="color:green;"><?php echo htmlspecialchars($message); ?></p>
<?php endif; ?>

<form method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
    <textarea name="comment" rows="4" cols="50" maxlength="500"></textarea><br>
    <button type="submit">Post Comment</button>
</form>

<h3>All Comments:</h3>
<?php foreach ($comments as $c): ?>
    <div style="border:1px solid #ccc; padding:10px; margin:5px 0;">
        <!-- SECURE: htmlspecialchars() prevents XSS on all output -->
        <strong><?php echo htmlspecialchars($c['username']); ?></strong>
        <small>(<?php echo htmlspecialchars($c['created_at']); ?>)</small>
        <p><?php echo nl2br(htmlspecialchars($c['content'])); ?></p>
    </div>
<?php endforeach; ?>
</body>
</html>
