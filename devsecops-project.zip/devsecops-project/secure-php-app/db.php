<?php
// SECURE: Use environment variables for credentials, never hardcode
$host     = getenv('DB_HOST')     ?: 'localhost';
$dbuser   = getenv('DB_USER')     ?: 'appuser';      // SECURE: Least privilege DB user
$dbpass   = getenv('DB_PASSWORD') ?: '';
$dbname   = getenv('DB_NAME')     ?: 'vulnapp';

$conn = new mysqli($host, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    // SECURE: Never expose error details to user
    error_log("DB Connection failed: " . $conn->connect_error);
    die("Service temporarily unavailable.");
}

// SECURE: Set charset to prevent encoding-based SQL injection
$conn->set_charset("utf8mb4");
?>
