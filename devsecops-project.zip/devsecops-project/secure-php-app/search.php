<?php
session_start();

// SECURE: Authentication check - only logged-in users can search
if (empty($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$results = [];
$searched = false;

if (isset($_GET['user'])) {
    $searched = true;
    $user = trim($_GET['user']);

    // SECURE: Input validation
    if (strlen($user) > 50) {
        die("Input too long.");
    }

    // SECURE: Prepared statement with parameterized query
    $stmt = $conn->prepare("SELECT id, username FROM users WHERE username = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $results[] = $row; // SECURE: Passwords never selected or shown
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Users</title>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'none';">
</head>
<body>
<h2>Search Users</h2>
<form method="GET">
    Username:
    <!-- SECURE: Output encoding on reflected input -->
    <input type="text" name="user" value="<?php echo htmlspecialchars($_GET['user'] ?? ''); ?>" maxlength="50">
    <button type="submit">Search</button>
</form>

<?php if ($searched): ?>
    <h3>Results:</h3>
    <?php if (!empty($results)): ?>
        <table border="1">
            <tr><th>ID</th><th>Username</th></tr>
            <?php foreach ($results as $row): ?>
                <!-- SECURE: htmlspecialchars() on ALL output from DB -->
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <!-- SECURE: No raw user input echoed back -->
        <p>No users found.</p>
    <?php endif; ?>
<?php endif; ?>
</body>
</html>
