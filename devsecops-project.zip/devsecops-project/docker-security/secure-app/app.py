from flask import Flask, jsonify
import os

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({
        "message": "Secure Flask App",
        "status": "Running as non-root user",
        "user": os.getenv("USER", "appuser")
    })

@app.route('/health')
def health():
    # SECURE: Health endpoint for Docker HEALTHCHECK
    return jsonify({"status": "healthy"}), 200

if __name__ == '__main__':
    # SECURE: Debug=False, reads secret from environment variable
    secret = os.getenv("SECRET_KEY", "")
    if not secret:
        raise RuntimeError("SECRET_KEY environment variable not set!")
    app.secret_key = secret
    app.run(host='0.0.0.0', port=5000, debug=False)
