from flask import Flask, request, jsonify
import os

app = Flask(__name__)

# VULNERABILITY: Debug mode enabled in production
# VULNERABILITY: Runs as root inside container
# VULNERABILITY: No input validation

@app.route('/')
def home():
    return jsonify({
        "message": "Insecure Flask App",
        "warning": "Running as root! No security hardening applied.",
        "user": os.popen("whoami").read().strip()  # VULNERABILITY: Command execution
    })

@app.route('/ping')
def ping():
    # VULNERABILITY: Command Injection via query param
    # Try: ?host=localhost;cat /etc/passwd
    host = request.args.get('host', 'localhost')
    result = os.popen(f"ping -c 1 {host}").read()
    return f"<pre>{result}</pre>"

@app.route('/health')
def health():
    return "OK", 200

if __name__ == '__main__':
    # VULNERABILITY: Debug=True, listening on all interfaces
    app.run(host='0.0.0.0', port=5000, debug=True)
